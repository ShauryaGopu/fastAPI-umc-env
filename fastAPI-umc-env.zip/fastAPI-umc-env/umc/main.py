from fastapi import FastAPI
from . import models
from .database import engine

###############################
from .routers import  umc, user, authentication, materialInfoTable

###############################

app = FastAPI()

#the below line is very important

models.Base.metadata.create_all(engine)


app.include_router(authentication.router)
app.include_router(umc.router)
app.include_router(user.router)
app.include_router(materialInfoTable.router)




