from pydantic import BaseModel
from typing import Optional
from typing import  List

# class Umc(Base):
#     __tablename__='umcs'
#     umc_id = Column(String(12),primary_key=True)
#     mpn = Column(String)
#     lot = Column(String)
#     dc  = Column(String)
#     ec_matcode = Column(String)
#     smf_matcode = Column(String,ForeignKey(materialInfoTable.smf_matcode))

#     user_id = Column(Integer, ForeignKey('users.id'))

#     creator = relationship("User", back_populates="umcs")





class UmcBase(BaseModel):
    umc_id : str 
    mpn : str
    lot : str
    dc : str
    ec_matcode : str
    smf_matcode : int

class Umc(UmcBase):
    class Config():
        orm_mode = True


#now we are gonna learn fastapi response models(pydantic schemas)
#which is used to return customized form of the model(hiddel field and more)
# it seems very exciting so far... keep it on.. keep learning you can do it with

class User(BaseModel):
    name : str 
    email : str 
    password : str


class ShowUser(BaseModel):
    name : str 
    email: str

    umcs : List[Umc] = []

    class Config():
        orm_mode = True


class ShowUmc(BaseModel):
    umc_id : str 
    mpn : str
    lot : str
    dc : str
    ec_matcode : str
    smf_matcode : int

    #creator : ShowUser

    ## since here we wanted to show the user info we have to code as above 😎
    class Config():
        orm_mode = True
        #for pydantic we have to do this. but really i don't know why 😒

################################################################

# from here I am making a materialInfoTableSchema for material info tables
# class MaterialInfoTable(Base):
#     __tablename__ = 'materialInfoTable'


#     smf_matcode = Column(Integer, primary_key=True)
#     materialDesc = Column(String)
#     materialType = Column(String)
#     materialSubtype = Column(String)



class MaterialInfoTable(BaseModel): 
    smf_matcode : int
    materialDesc : str
    materialType : str
    materialSubtype : str









class Login(BaseModel):
    username: str
    password: str

################################################################
# lets start JWT tokens, its fun... hurray 😁😁😁

class Token(BaseModel):
    access_token : str
    token_type: str

class TokenData(BaseModel): 
    email: Optional[str] = None
    
