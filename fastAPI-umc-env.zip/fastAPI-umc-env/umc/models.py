from sqlalchemy import Column, Integer, String, ForeignKey
from .database import  Base
from sqlalchemy.orm import relationship







class Umc(Base):
    __tablename__='umcs'


    #id = Column(Integer, primary_key=True, index=True)
    umc_id = Column(String(12),primary_key=True)
    mpn = Column(String)
    lot = Column(String)
    dc  = Column(String)
    ec_matcode = Column(String)
    smf_matcode = Column(Integer,ForeignKey('materialInfoTable.smf_matcode'))

    user_id = Column(Integer, ForeignKey('users.id'))

    creator = relationship("User", back_populates="umcs")


class User(Base):
    __tablename__ = 'users'


    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    email = Column(String)
    password = Column(String)

    umcs = relationship("Umc",back_populates="creator")

class MaterialInfoTable(Base):
    __tablename__ = 'materialInfoTable'


    smf_matcode = Column(Integer, primary_key=True)
    materialDesc = Column(String)
    materialType = Column(String)
    materialSubtype = Column(String)

