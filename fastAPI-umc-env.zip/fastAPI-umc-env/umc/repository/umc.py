from sqlalchemy.orm import  Session
from .. import models, schemas
from fastapi import HTTPException, status, Response


def get_all(db: Session):
    umcs = db.query(models.Umc).all()
    return umcs

    # umc_id = Column(String(12),primary_key=True)
    # mpn = Column(String)
    # lot = Column(String)
    # dc  = Column(String)
    # ec_matcode = Column(String)
    # smf_matcode = Column(String,ForeignKey('materialInfoTable.smf_matcode'))

    # user_id = Column(Integer, ForeignKey('users.id'))

    # creator = relationship("User", back_populates="umcs")



def create(request: schemas.Umc, db: Session):
    new_umc = models.Umc(umc_id=request.umc_id, mpn=request.mpn, lot=request.lot, dc =request.dc, ec_matcode=request.ec_matcode,smf_matcode=request.smf_matcode ,user_id=1)
    db.add(new_umc)
    db.commit()
    db.refresh(new_umc)
    return new_umc

# def get_umc(id, db: Session):
#     #umc = db.query(models.Umc).filter((models.Umc.id == id)).first()
#     #above will also work
#     umc = db.query(models.Umc).get(id)
#     if not umc:
#         # response.status_code = status.HTTP_404_NOT_FOUND
#         # return {'detail':f"Umc with the id {id} is not available"}
#         raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail = f"Umc with the id {id} is not available" )
#     return umc

# def delete(id, db:Session):
#     umc = db.query(models.Umc).filter(models.Umc.id == id)
    
#     if not umc.first():
#         raise HTTPException(status_code= status.HTTP_404_NOT_FOUND, detail=f"Umc with ID {id} is not found, may be deleted 😁 ")
#     else :
#        umc.delete(synchronize_session=False)
#     #umc = wrong...db.query(models.Umc).get(id).delete(synchronize_session=False)
#     db.commit()
#     return Response(status_code= status.HTTP_404_NOT_FOUND)

# def update(request: schemas.Umc,id, db: Session):
#     umc = db.query(models.Umc).filter(models.Umc.id == id)
#     if not umc.first():
#         raise HTTPException(status_code= status.HTTP_404_NOT_FOUND, detail=f"Umc with ID {id} is not found")
#     else :
#         umc.update({'title':request.title,'body':request.body})
#     #umc = db.query(models.Umc).filter(models.Umc.id == id).update(request)
#     db.commit()
#     return 'updated'