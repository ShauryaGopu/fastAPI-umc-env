from sqlalchemy.orm import  Session
from .. import models, schemas
from fastapi import HTTPException, status, Response


def get_all(db: Session):
    materials = db.query(models.MaterialInfoTable).all()
    return materials

# smf_matcode = Column(Integer, primary_key=True)
#     materialDesc = Column(String)
#     materialType = Column(String)
#     materialSubtype = Column(String)



def create(request: schemas.MaterialInfoTable, db: Session):
    new_material = models.MaterialInfoTable(smf_matcode=request.smf_matcode,materialDesc=request.materialDesc, materialType=request.materialType, materialSubtype=request.materialSubtype)
    db.add(new_material)
    db.commit()
    db.refresh(new_material)
    return new_material

# def get_umc(id, db: Session):
#     #umc = db.query(models.Umc).filter((models.Umc.id == id)).first()
#     #above will also work
#     umc = db.query(models.Umc).get(id)
#     if not umc:
#         # response.status_code = status.HTTP_404_NOT_FOUND
#         # return {'detail':f"Umc with the id {id} is not available"}
#         raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail = f"Umc with the id {id} is not available" )
#     return umc

# def delete(id, db:Session):
#     umc = db.query(models.Umc).filter(models.Umc.id == id)
    
#     if not umc.first():
#         raise HTTPException(status_code= status.HTTP_404_NOT_FOUND, detail=f"Umc with ID {id} is not found, may be deleted 😁 ")
#     else :
#        umc.delete(synchronize_session=False)
#     #umc = wrong...db.query(models.Umc).get(id).delete(synchronize_session=False)
#     db.commit()
#     return Response(status_code= status.HTTP_404_NOT_FOUND)

# def update(request: schemas.Umc,id, db: Session):
#     umc = db.query(models.Umc).filter(models.Umc.id == id)
#     if not umc.first():
#         raise HTTPException(status_code= status.HTTP_404_NOT_FOUND, detail=f"Umc with ID {id} is not found")
#     else :
#         umc.update({'title':request.title,'body':request.body})
#     #umc = db.query(models.Umc).filter(models.Umc.id == id).update(request)
#     db.commit()
#     return 'updated'