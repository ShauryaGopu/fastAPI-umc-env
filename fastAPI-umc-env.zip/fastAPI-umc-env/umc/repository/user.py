from sqlalchemy.orm import Session
from .. import schemas, models, hashing
from fastapi import HTTPException, status, Response


def create(request: schemas.Umc, db: Session):
    new_user = models.User(name=request.name, email = request.email, password = hashing.Hash.bcrypt(request.password))
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

def get(id, db: Session):
    user = db.query(models.User).get(id)
    if not user:
        raise HTTPException(status_code= status.HTTP_404_NOT_FOUND, detail=f"user {id} is not available")
    else:
        return user

def get_all(db: Session):
    users = db.query(models.User).all()
    return users

def delete(id, db: Session):
    user = db.query(models.User).filter(models.User.id == id)
    if not user.first():
        return HTTPException(status_code= status.HTTP_404_NOT_FOUND,detail=f"user {id} is not available")
    else:
        user.delete(synchronize_session=False)
    db.commit()
    return Response(status_code = status.HTTP_404_NOT_FOUND)

def update(id,request:schemas.User,db: Session):
    user = db.query(models.User).filter(models.User.id == id)
    if not user.first():
        return HTTPException(status_code= status.HTTP_404_NOT_FOUND,detail=f"user {id} is not available")
    else:
        user.update({'name':request.name,'email':request.email,'password':request.password})
    db.commit()
    return 'updated'