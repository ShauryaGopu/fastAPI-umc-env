from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.engine import URL

############################ below is working for sqllite

# SQLALCHEMY_DATABASE_URL = 'sqlite:/// umc.db'
# #SQLALCHEMY_DATABASE_URL = 'sqlite:/// ./umc.db'   #usual way
# # SQLALCHEMY_DATABASE_URL = "postgresql://user:password@postgresser/db"


# engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread":False})

############################ above is working for sqllite


################from below I am trying to connect with mssql let's c what happens

connection_string = "DRIVER={ODBC Driver 17 for SQL Server};SERVER=localhost;DATABASE=Umc;UID=sa;PWD=premchand"
connection_url = URL.create("mssql+pyodbc", query={"odbc_connect": connection_string})
engine = create_engine(connection_url)



#################above code I am trying to connect with mssql
#################I have really connected with sql server.. great job gopu

SessionLocal =sessionmaker(bind=engine, autocommit=False, autoflush=False)

Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()