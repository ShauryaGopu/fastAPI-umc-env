from fastapi import APIRouter, Depends
from typing import List

from .. import schemas, database



from sqlalchemy.orm import Session

################################
from ..repository import  user

router = APIRouter(
    prefix="/user",
    tags = ['Users']
)




get_db = database.get_db


@router.post('/', response_model=schemas.ShowUser)
def create_user(request: schemas.User, db:Session = Depends(get_db)):
    return user.create(request, db)
    

@router.get('/{id}', response_model = schemas.ShowUser)
def show_user(id, db:Session = Depends(get_db)):
    return user.get(id, db)

@router.get('/', response_model = List[schemas.ShowUser])
def all_user(db:Session = Depends(get_db)):
    return user.get_all(db)

@router.delete('/{id}')
def user_delete(id, db:Session = Depends(get_db)):
    return user.delete(id, db)

@router.put('/', tags=['Users', ])
def user_update(id,request: schemas.User, db:Session = Depends(get_db)):
    return user.update(id,request,db)