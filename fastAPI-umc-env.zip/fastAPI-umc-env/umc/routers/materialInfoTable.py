from fastapi import APIRouter,Depends, status
from .. import schemas, database
from typing import List
from sqlalchemy.orm import Session

################################################################
from ..repository import  materialInfoTable

from .. import oauth2

router = APIRouter(
    prefix="/materialInfo",
    tags=['MaterialInfo']
)
get_db = database.get_db


@router.get('/', response_model= List[schemas.MaterialInfoTable])
def get_all_materials(db: Session = Depends(get_db), current_user: schemas.User = Depends(oauth2.get_current_user)):
    return materialInfoTable.get_all(db)
    

@router.post('/', status_code=status.HTTP_201_CREATED)
def create(request: schemas.MaterialInfoTable, db: Session = Depends(get_db), current_user: schemas.User = Depends(oauth2.get_current_user)):
     return materialInfoTable.create(request, db)